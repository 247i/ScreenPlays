package net.veierland.aixd.widget;

@SuppressWarnings("serial")
public class AixWidgetDataException extends Exception {

	public AixWidgetDataException(String message) {
		super(message);
	}
	
}
