package net.veierland.aixd.widget;

@SuppressWarnings("serial")
public class AixWidgetDrawException extends Exception {
	
	public AixWidgetDrawException(String message) {
		super(message);
	}
	
}
