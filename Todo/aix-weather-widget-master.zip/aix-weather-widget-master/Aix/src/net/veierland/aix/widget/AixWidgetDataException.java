package net.veierland.aix.widget;

@SuppressWarnings("serial")
public class AixWidgetDataException extends Exception {

	public AixWidgetDataException(String message) {
		super(message);
	}
	
}
