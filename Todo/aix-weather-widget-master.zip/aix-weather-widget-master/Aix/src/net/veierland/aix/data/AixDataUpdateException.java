package net.veierland.aix.data;


@SuppressWarnings("serial")
public class AixDataUpdateException extends Exception {
	
	public AixDataUpdateException()
	{
		super();
	}
	
	public AixDataUpdateException(String message)
	{
		super(message);
	}
	
}
