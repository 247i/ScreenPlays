package net.veierland.aix.widget;

@SuppressWarnings("serial")
public class AixWidgetDrawException extends Exception {
	
	public AixWidgetDrawException(String message) {
		super(message);
	}
	
}
